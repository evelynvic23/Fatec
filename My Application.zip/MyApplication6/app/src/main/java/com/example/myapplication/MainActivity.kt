package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    private lateinit var databaseHelper: DatabaseHelper
    private lateinit var editTextCpf: EditText
    private lateinit var editTextNome: EditText
    private lateinit var editTextIdade: EditText
    private lateinit var editTextPeso: EditText
    private lateinit var editTextAltura: EditText
    private lateinit var buttonCalcularIMC: Button
    private lateinit var buttonSalvarDados: Button
    private lateinit var textViewResultadoIMC: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        databaseHelper = DatabaseHelper(this)

        // Vinculando os componentes da UI
        editTextCpf = findViewById(R.id.editTextCpf)
        editTextNome = findViewById(R.id.editTextNome)
        editTextIdade = findViewById(R.id.editTextIdade)
        editTextPeso = findViewById(R.id.editTextPeso)
        editTextAltura = findViewById(R.id.editTextAltura)
        buttonCalcularIMC = findViewById(R.id.buttonCalcularIMC)
        buttonSalvarDados = findViewById(R.id.buttonSalvarDados)
        textViewResultadoIMC = findViewById(R.id.textViewResultadoIMC)

        // Botão Calcular IMC
        buttonCalcularIMC.setOnClickListener {
            val pesoText = editTextPeso.text.toString()
            val alturaText = editTextAltura.text.toString()

            val peso = pesoText.toDoubleOrNull()
            val altura = alturaText.toDoubleOrNull()

            if (peso != null && altura != null && altura > 0) {
                textViewResultadoIMC.text = calcIMC(peso, altura)
            } else {
                Toast.makeText(this, "Preencha corretamente peso e altura", Toast.LENGTH_SHORT).show()
            }
        }

        // Botão Salvar Dados
        buttonSalvarDados.setOnClickListener {
            val cpf = editTextCpf.text.toString()
            val nome = editTextNome.text.toString()
            val idade = editTextIdade.text.toString().toIntOrNull()
            val peso = editTextPeso.text.toString().toDoubleOrNull()
            val altura = editTextAltura.text.toString().toDoubleOrNull()

            if (cpf.isNotEmpty() && nome.isNotEmpty() && idade != null && peso != null && altura != null) {
                val pessoa = Pessoa(cpf, nome, idade, altura, peso)

                databaseHelper.insertPessoa(pessoa.cpf, pessoa.nome, pessoa.idade, pessoa.altura, pessoa.peso)

                Toast.makeText(this, "Dados salvos com sucesso!", Toast.LENGTH_SHORT).show()
                Log.i("appBD", "Lista de pessoas: ${databaseHelper.getAllPessoas()}")

                // Limpar os campos
                editTextCpf.text.clear()
                editTextNome.text.clear()
                editTextIdade.text.clear()
                editTextPeso.text.clear()
                editTextAltura.text.clear()
                textViewResultadoIMC.text = ""

            } else {
                Toast.makeText(this, "Preencha todos os campos corretamente", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Função para calcular o IMC
    private fun calcIMC(peso: Double, altura: Double): String {
        val imc = peso / (altura * altura)
        val imcFormatted = String.format("%.2f", imc)
        return "Seu IMC é: $imcFormatted"
    }
}
