package com.example.myapplication

data class Pessoa(
    val cpf: String,
    val nome: String,
    val idade: Int,
    val altura: Double,
    val peso: Double
)


